package com.uci.user.ari;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class CheckStatusService extends IntentService {
    private final String alarmUrl = "http://190.155.112.105:443/check.php";
    private final String patientUrl = "http://190.155.112.105:443/patientCheck.php";

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private static final String TAG_ALERTA = "alerta";
    private JSONParser jsonParser = new JSONParser();
    private int successA,successP,alerta,rol=3;
    private ArrayList<Integer> ar_camas=new ArrayList<>();

    public CheckStatusService() {

        super("CheckStatusService");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        SharedPreferences sharedPref = CheckStatusService.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);

        ar_camas.add(R.id.secACama1);
        ar_camas.add(R.id.secACama2);
        ar_camas.add(R.id.secACama3);
        ar_camas.add(R.id.secACama4);
        ar_camas.add(R.id.secACama5);
        ar_camas.add(R.id.secACama6);
        ar_camas.add(R.id.secACama7);
        ar_camas.add(R.id.secACama8);
        ar_camas.add(R.id.secACama9);
        ar_camas.add(R.id.secACama10);
        ar_camas.add(R.id.secACama11);
        ar_camas.add(R.id.secACama12);
        ar_camas.add(R.id.secACama13);
        ar_camas.add(R.id.secACama14);
        //BUSCA LOS DATOS POR
        rol = sharedPref.getInt(getString(R.string.data_rol),0);
        new AttemptCheckAlarm().execute();
        return Service.START_NOT_STICKY;
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        try {
            // Building Parameters
            List parametros = new ArrayList();
            List parametrosP = new ArrayList();
            parametros.add(new BasicNameValuePair(getString(R.string.data_rol), Integer.toString(rol)));

            // getting product details by making HTTP request
            JSONObject json = jsonParser.makeHttpRequest(alarmUrl, "POST", parametros);


            // json success tag
            successA = json.getInt(TAG_SUCCESS);
            if (successA == 1)
            {
                alerta = json.getInt(TAG_ALERTA);
                if(alerta==1)
                {
                    //GUARDO DATOS INDICANDO EL CAMBIO DE COLOR
                    SharedPreferences sharedPref = this.getSharedPreferences(
                            getString(R.string.preferencs_file), Context.MODE_PRIVATE);
                    SharedPreferences.Editor edit = sharedPref.edit();

                    int counter=0;
                    StringBuilder sectorAlarm= new StringBuilder();
                    ArrayList<String> ar_patient=(ArrayList<String>) json.get("patientID");
                    ArrayList<String> ar_paramID=(ArrayList<String>) json.get("paramID");//VERIFICAR QUE TIENE EL PARAM ID STATUS
                    //////////////////////////////////////////
                    //HEY REVISAAARRRR
                    ////////////////////////////
                    TreeMap<String,ArrayList<String>> pat_par=new TreeMap<>();

                    TreeMap<String,String> pat_cam=new TreeMap<>();
                    TreeMap<String,String> pat_sec=new TreeMap<>();
                    for(String patient: ar_patient )
                    {
                        String sector,cama,param;
                        if(!pat_par.containsKey(patient))
                        {
                            pat_par.put(patient,new ArrayList<String>());

                            parametrosP.add(new BasicNameValuePair(getString(R.string.paciente), patient));
                            JSONObject json2 = jsonParser.makeHttpRequest(patientUrl, "POST", parametrosP);

                            // json success tag
                            successP = json2.getInt(TAG_SUCCESS);
                            if (successP == 1) {
                                sector = json.getString("sector");
                                cama = json.getString("cama");
                                sectorAlarm.append(sector).append(" ");

                                //INGRESO LOS DATOS AL ARCHIVO PARA LUEGO LEERLOS
                                //NOMBRE, VALOR (0 verde, 1 rojo)
                                //sector_#sector
                                //cama_#cama_#sector
                                //param_#param_#cama_#sector
                                edit.putInt(getString(R.string.data_alarm_sector)+"_"+sector,1);
                                edit.putInt(getString(R.string.data_alarm_cama)+"_"+cama+"_"+sector, 1);

                                pat_sec.put(patient,sector);
                                pat_cam.put(patient,cama);
                            }
                        }
                        param = ar_paramID.get(counter);
                        pat_par.get(patient).add(param);

                        edit.putInt(getString(R.string.data_par_cam_sec)+"_"+param+"_"+pat_cam.get(patient)+"_"+pat_sec.get(patient),1);

                        counter+=1;
                    }

                    edit.apply();

                    //GENERO LA NOTIFICACION
                    NotificationCompat.Builder mBuilder;
                    NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

                    int icono = R.drawable.icon_c;
                    Intent i=new Intent(CheckStatusService.this, CheckStatusService.class);
                    PendingIntent pendingIntent = PendingIntent.getActivity(CheckStatusService.this, 0, i, 0);

                    mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                            .setContentIntent(pendingIntent)
                            .setSmallIcon(icono)
                            .setContentTitle(getString(R.string.alerta))
                            .setContentText("Existe una emergencia en:"+sectorAlarm)
                            .setVibrate(new long[] {100, 250, 100, 500,100, 250, 100, 500})
                            .setAutoCancel(true)
                            .setPriority(Notification.PRIORITY_MAX)
                            .setColor(0xff00ff00)
                            .setLights(0xff00ff00,300,1000)
                            .setOnlyAlertOnce(false);


                    mNotifyMgr.notify(2, mBuilder.build());
                }
                else
                {
                    Log.d("Success!", json.getString(TAG_MESSAGE));
                }

            }
            else
            {
                Log.d("Connection Failure!", json.getString(TAG_MESSAGE));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private class AttemptCheckAlarm extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            String msg="";

            //GUARDO DATOS INDICANDO EL CAMBIO DE COLOR
            SharedPreferences sharedPref = CheckStatusService.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPref.edit();
            try {
                // Building Parameters
                List parametros = new ArrayList();
                List parametrosP = new ArrayList();
                parametros.add(new BasicNameValuePair(getString(R.string.data_rol), Integer.toString(rol)));

                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(alarmUrl, "POST", parametros);

                // json success tag
                successA = json.getInt(TAG_SUCCESS);
                if (successA == 1 && json.has(TAG_ALERTA))
                {
                    alerta = json.getInt(TAG_ALERTA);
                    if(alerta==1)
                    {

                        int counter=1;
                        StringBuilder sectorAlarm= new StringBuilder();
                        final ObjectMapper objectMapper = new ObjectMapper();
                        final TreeMap<String, String> ar_patient = objectMapper.readValue(json.get("patientID").toString(), TreeMap.class);
                        final TreeMap<String, String> ar_paramID = objectMapper.readValue(json.get("paramID").toString(), TreeMap.class);//VERIFICAR QUE TIENE EL PARAM ID STATUS
                        //////////////////////////////////////////
                        //HEY REVISAAARRRR
                        ////////////////////////////

                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"A");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"B");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"C");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"D");
                        edit.remove("chequeado");
                        for (int j=0; j<14; j++)
                        {
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"A");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"B");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"C");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"D");
                        }
                        edit.apply();

                        TreeMap<String,ArrayList<String>> pat_par=new TreeMap<>();

                        TreeMap<String,String> pat_cam=new TreeMap<>();
                        TreeMap<String,String> pat_sec=new TreeMap<>();
                        for(String patient: ar_patient.values() )
                        {
                            String sector,cama,param;
                            if(!pat_par.containsKey(patient))
                            {
                                pat_par.put(patient,new ArrayList<String>());

                                parametrosP.add(new BasicNameValuePair(getString(R.string.paciente), patient));
                                JSONObject json2 = jsonParser.makeHttpRequest(patientUrl, "POST", parametrosP);

                                // json success tag
                                successP = json2.getInt(TAG_SUCCESS);
                                if (successP == 1) {
                                    sector = json2.getString("sector");
                                    cama = json2.getString("cama");
                                    if(!sectorAlarm.toString().contains(sector))
                                    {
                                        sectorAlarm.append(sector).append(";");
                                    }


                                    //INGRESO LOS DATOS AL ARCHIVO PARA LUEGO LEERLOS
                                    //NOMBRE, VALOR (0 verde, 1 rojo)
                                    //sector_#sector
                                    //cama_#cama_#sector
                                    //param_#param_#cama_#sector
                                    edit.putInt(getString(R.string.data_alarm_sector)+"_"+sector,1);
                                    edit.putInt(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(Integer.parseInt(cama)-1)+"_"+sector, 1);

                                    pat_sec.put(patient,sector);
                                    pat_cam.put(patient,cama);
                                }
                            }
                            param = ar_paramID.get(Integer.toString(counter));
                            pat_par.get(patient).add(param);

                            edit.putInt(getString(R.string.data_par_cam_sec)+"_"+param+"_"+pat_cam.get(patient)+"_"+pat_sec.get(patient),1);

                            counter+=1;
                        }
                        edit.putInt("chequeado",1);
                        edit.apply();

                        //GENERO LA NOTIFICACION
                        NotificationCompat.Builder mBuilder;
                        NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

                        int icono = R.drawable.icon_c;
                        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

                        Intent i=new Intent(CheckStatusService.this, Sectores.class);
                        PendingIntent pendingIntent = PendingIntent.getActivity(CheckStatusService.this, 0, i, 0);

                        mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                                .setContentIntent(pendingIntent)
                                .setSmallIcon(icono)
                                .setContentTitle(getString(R.string.alerta))
                                .setContentText("Existe una emergencia en el Sector: "+sectorAlarm)
                                .setVibrate(new long[] {100, 250, 100, 500,100, 250, 100, 500})
                                .setSound(alarmSound)
                                .setAutoCancel(true)
                                .setPriority(Notification.PRIORITY_MAX)
                                .setColor(0xff00ff00)
                                .setLights(0xff00ff00,300,1000)
                                .setOnlyAlertOnce(false);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            mBuilder.setChannelId("com.ARI");
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            NotificationChannel channel = new NotificationChannel(
                                    "com.ARI",
                                    "ARI",
                                    NotificationManager.IMPORTANCE_DEFAULT
                            );
                            if (mNotifyMgr != null) {
                                mNotifyMgr.createNotificationChannel(channel);
                            }
                        }
                        mNotifyMgr.notify(2, mBuilder.build());
                    }
                    else
                    {
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"A");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"B");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"C");
                        edit.remove(getString(R.string.data_alarm_sector)+"_"+"D");
                        edit.remove("chequeado");
                        for (int j=0; j<14; j++)
                        {
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"A");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"B");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"C");
                            edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"D");

                            for(int k=1; k<11; k++)
                            {
                                edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"A");
                                edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"B");
                                edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"C");
                                edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"D");
                            }

                        }
                        edit.putInt("chequeado",1);
                        edit.apply();
                        Log.d("Success!", json.getString(TAG_MESSAGE));
                    }

                }
                else
                {
                    edit.remove(getString(R.string.data_alarm_sector)+"_"+"A");
                    edit.remove(getString(R.string.data_alarm_sector)+"_"+"B");
                    edit.remove(getString(R.string.data_alarm_sector)+"_"+"C");
                    edit.remove(getString(R.string.data_alarm_sector)+"_"+"D");
                    edit.remove("chequeado");
                    for (int j=0; j<14; j++)
                    {
                        edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"A");
                        edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"B");
                        edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"C");
                        edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"D");

                        for(int k=1; k<11; k++)
                        {
                            edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"A");
                            edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"B");
                            edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"C");
                            edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"D");
                        }
                    }
                    edit.putInt("chequeado",1);
                    edit.apply();
                    Log.d("Connection Failure!", json.getString(TAG_MESSAGE));
                }
                return json.getString(TAG_MESSAGE);
            } catch (Exception e) {
                edit.remove(getString(R.string.data_alarm_sector)+"_"+"A");
                edit.remove(getString(R.string.data_alarm_sector)+"_"+"B");
                edit.remove(getString(R.string.data_alarm_sector)+"_"+"C");
                edit.remove(getString(R.string.data_alarm_sector)+"_"+"D");
                edit.remove("chequeado");
                for (int j=0; j<14; j++)
                {
                    edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"A");
                    edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"B");
                    edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"C");
                    edit.remove(getString(R.string.data_alarm_cama)+"_"+ar_camas.get(j)+"_"+"D");

                    for(int k=1; k<11; k++)
                    {
                        edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"A");
                        edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"B");
                        edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"C");
                        edit.remove(getString(R.string.data_par_cam_sec)+"_"+k+"_"+j+"_"+"D");
                    }
                }
                edit.putInt("chequeado",1);
                edit.apply();
                e.printStackTrace();
            }

            return msg;
        }
    }
}

