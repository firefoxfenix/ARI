package com.uci.user.ari;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.view.LineChartView;

public class GraficoParametro extends AppCompatActivity {


    private final String serverUrl = "http://190.155.112.105:443/bedRoomCheck.php";
    private final String patientUrl= "http://190.155.112.105:443/parameterGraph.php";
    private final String serverUrlRecent="http://190.155.112.105:443/parameterData.php";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private JSONParser jsonParser = new JSONParser();

    private int sectorId=0,camaId=0,parametroId=0,paraNum=1;
    private int error=0,j=0;
    private String title="Sector ";
    private String nombre_paciente, y_Axis_title,parametro_text;
    private int rol=3;
    private Button tendencia;
    private TextView ultimoValor;
    private boolean isCancelled=false;
    private ProgressDialog dialog;

    private LineChartView lineChartView;
    private Handler mHandler=null;
    private List yAxisValues = new ArrayList();
    private ArrayList<Float> dataY=new ArrayList<>();
    private ArrayList<Float> dataX=new ArrayList<>();
    private ArrayList<String> dataYString=new ArrayList<>();
    private ArrayList<String> dataXString=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_grafico);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SharedPreferences sharedPref = GraficoParametro.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        rol = sharedPref.getInt(getString(R.string.data_rol),0);

        tendencia= findViewById(R.id.buttonTendence);
        tendencia.setOnClickListener(tendenceListener);

        ultimoValor= findViewById(R.id.textLastValue);

        dialog=new ProgressDialog(GraficoParametro.this);
        dialog.setMessage("Cargando...");
        dialog.setCancelable(false);
        dialog.setInverseBackgroundForced(false);
        dialog.show();

        Bundle b=this.getIntent().getExtras();
        if(b!=null)
        {
            sectorId=b.getInt("noSector");
            camaId=b.getInt("noCama");
            parametroId=b.getInt("noParameter");
        }

        ArrayList<Button> buttons=new ArrayList<>();

        switch(sectorId)
        {
            case 0:
            {
                title+="A > ";
                break;
            }
            case 1:
            {
                title+="B > ";
                break;
            }
            case 2:
            {
                title+="C > ";
                break;
            }
            case 3:
            {
                title+="D > ";
                break;
            }
        }

        switch(camaId)
        {
            case R.id.secACama1:
            {
                title+="Cama 1";
                break;
            }
            case R.id.secACama2:
            {
                title+="Cama 2";
                break;
            }
            case R.id.secACama3:
            {
                title+="Cama 3";
                break;
            }
            case R.id.secACama4:
            {
                title+="Cama 4";
                break;
            }
            case R.id.secACama5:
            {
                title+="Cama 5";
                break;
            }
            case R.id.secACama6:
            {
                title+="Cama 6";
                break;
            }
            case R.id.secACama7:
            {
                title+="Cama 7";
                break;
            }
            case R.id.secACama8:
            {
                title+="Cama 8";
                break;
            }
            case R.id.secACama9:
            {
                title+="Cama 9";
                break;
            }
            case R.id.secACama10:
            {
                title+="Cama 10";
                break;
            }
            case R.id.secACama11:
            {
                title+="Cama 11";
                break;
            }
            case R.id.secACama12:
            {
                title+="Cama 12";
                break;
            }
        }

        switch(parametroId)
        {
            case R.id.btnPar1:
            {
                title+="> Presión";
                y_Axis_title ="Presión";
                parametro_text="PR";
                break;
            }
            case R.id.btnPar2:
            {
                title+="> Frec.";
                y_Axis_title ="Frecuencia Cardiaca(lpm)";
                paraNum=2;
                parametro_text="HR";
                break;
            }
            case R.id.btnPar3:
            {
                title+="> Temp.";
                y_Axis_title ="Temperatura(C)";
                paraNum=3;
                parametro_text="T";
                break;
            }
            case R.id.btnPar4:
            {
                title+="> Oxig.";
                y_Axis_title ="Oxigenación(%)";
                paraNum=4;
                parametro_text="QT";
                break;
            }
            case R.id.btnPar5:
            {

                title+="> QRSDUR";
                y_Axis_title ="QRSDUR";
                paraNum=5;
                parametro_text="QRSDUR";
                break;
            }
            case R.id.btnPar6:
            {
                title+="> QTC.";
                y_Axis_title ="QTC";
                paraNum=6;
                parametro_text="QTC";
                break;
            }
            case R.id.btnPar7:
            {
                title+="> Pulso";
                y_Axis_title ="Pulso";
                paraNum=7;
                parametro_text="P";
                break;
            }
            case R.id.btnPar8:
            {
                title+="> QRS";
                y_Axis_title ="QRS";
                paraNum=8;
                parametro_text="QRS";
                break;
            }
            case R.id.btnPar9:
            {
                title+="> RV5";
                y_Axis_title ="RV5";
                paraNum=9;
                parametro_text="RV5";
                break;
            }
            case R.id.btnPar10:
            {
                title+="> SV1";
                y_Axis_title ="SV1";
                paraNum=10;
                parametro_text="SV1";
                break;
            }
        }

        setTitle(title);

        new AttemptPatientData().execute();

    }

    @Override
    protected void onStop() {
        this.mHandler.removeCallbacks(this.m_Runnable);
        isCancelled=true;
        super.onStop();
    }

    @Override
    protected void onPause() {
        isCancelled=true;
        super.onPause();
    }

    @Override
    protected void onResume() {
        isCancelled=false;
        super.onResume();
    }

    private View.OnClickListener tendenceListener= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent n_activity=new Intent(view.getContext(),GraficoTendencias.class);

            n_activity.putExtra("noSector",sectorId);
            n_activity.putExtra("noCama",camaId);
            n_activity.putExtra("noParameter",parametroId);
            startActivity(n_activity);
        }
    };

    private final Runnable m_Runnable = new Runnable()
    {
        public void run()

        {
            new AttemptLastData().execute();
            ultimoValor.setText(dataY.get(dataY.size()-1).toString());

            Line line = new Line(yAxisValues).setColor(Color.parseColor("#FFFFFF"));
            yAxisValues.remove(0);
            yAxisValues.add(new PointValue(dataX.get(dataX.size()-1),dataY.get(dataY.size()-1)));


            List lines = new ArrayList();
            lines.add(line);
            line.setHasPoints(false);

            LineChartData data = new LineChartData();
            data.setLines(lines);

            Axis axis = new Axis();//Axis.generateAxisFromCollection(dataX,dataXString);
            axis.setTextSize(10);
            axis.setName("Tiempo");
            axis.setTextColor(Color.parseColor("#FFFFFF"));
            data.setAxisXBottom(axis);

            Axis yAxis = new Axis();//Axis.generateAxisFromCollection(dataY,dataYString);
            yAxis.setName(y_Axis_title);    //NOMBRE DE LA LINEA IZQUIERDA
            yAxis.setTextColor(Color.parseColor("#FFFFFF"));
            yAxis.setTextSize(10);
            data.setAxisYLeft(yAxis);

            lineChartView.setLineChartData(data);


            GraficoParametro.this.mHandler.postDelayed(m_Runnable, 500);
        }

    };

    private class AttemptPatientData extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success,i=1;
            try {

                List parametros = new ArrayList();
                parametros.add(new BasicNameValuePair("cama", title.substring(title.lastIndexOf("a")+2,title.lastIndexOf("a")+3).trim()));
                parametros.add(new BasicNameValuePair("sector", title.substring(title.indexOf("r")+1,title.indexOf(">")).trim()));

                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1)
                {
                    nombre_paciente=json.getString("apellido")+" "+json.getString("nombre");


                    parametros = new ArrayList();
                    parametros.add(new BasicNameValuePair("id", json.getString("PatientIID")));
                    parametros.add(new BasicNameValuePair("parameter", Integer.toString(paraNum)));

                    // getting product details by making HTTP request
                    JSONObject json2 = jsonParser.makeHttpRequest(patientUrl, "POST", parametros);

                    while(json2.has("y"+i) && json2.has("x"+i))
                    {
                        dataY.add(((Double)json2.getDouble("y"+i)).floatValue());
                        dataYString.add(((Double)json2.getDouble("y"+i)).toString());
                        dataX.add(i+0f);
                        dataXString.add(((Float)(i+0f)).toString());
                        i++;
                    }

                    GraficoParametro.this.runOnUiThread(new Runnable() {
                        public void run()
                        {
                            lineChartView = findViewById(R.id.chart);

                            Line line = new Line(yAxisValues).setColor(Color.parseColor("#FFFFFF"));
                            line.setHasPoints(false);

                            for (int i = 0; i < dataY.size(); i++) {
                                yAxisValues.add(new PointValue(dataX.get(i), dataY.get(i)));
                            }

                            List lines = new ArrayList();
                            lines.add(line);

                            LineChartData data = new LineChartData();
                            data.setLines(lines);

                            Axis axis = new Axis();//Axis.generateAxisFromCollection(dataX,dataXString);
                            axis.setTextSize(10);
                            axis.setName("Tiempo");
                            axis.setTextColor(Color.parseColor("#FFFFFF"));
                            data.setAxisXBottom(axis);

                            Axis yAxis = new Axis();//Axis.generateAxisFromCollection(dataY,dataYString);
                            yAxis.setName(y_Axis_title);    //NOMBRE DE LA LINEA IZQUIERDA
                            yAxis.setTextColor(Color.parseColor("#FFFFFF"));
                            yAxis.setTextSize(10);
                            data.setAxisYLeft(yAxis);

                            lineChartView.setLineChartData(data);

                            mHandler = new Handler();
                            mHandler.postDelayed(m_Runnable,500);
                        }
                    });
                    error=0;
                    return json2.getString(TAG_MESSAGE);

                }
                else
                {
                    Log.d("Data Failure!", json.getString(TAG_MESSAGE));
                    return json.getString(TAG_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error de conexión con el servidor!";
            }

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String file_url)
        {
            // dismiss the dialog once product deleted
            if (file_url != null && !file_url.isEmpty() && !file_url.contains("correcto") && error==0) {
                error=1;
                Toast.makeText(GraficoParametro.this, file_url, Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        }


    }

    private class AttemptLastData extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success,i=1;
            Float dataRecent;
            if(isCancelled)
            {
                return "correcto";
            }
            try {

                List parametros = new ArrayList();
                parametros.add(new BasicNameValuePair("cama", title.substring(title.lastIndexOf("a")+2,title.lastIndexOf("a")+3).trim()));
                parametros.add(new BasicNameValuePair("sector", title.substring(title.indexOf("r")+1,title.indexOf(">")).trim()));

                JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1)
                {
                    nombre_paciente=json.getString("apellido")+" "+json.getString("nombre");


                    parametros = new ArrayList();
                    parametros.add(new BasicNameValuePair("id", json.getString("PatientIID")));

                    // getting product details by making HTTP request
                    JSONObject json2 = jsonParser.makeHttpRequest(serverUrlRecent, "POST", parametros);

                    dataRecent=Float.parseFloat(json2.getString(parametro_text));

                    dataY.remove(0);
                    dataX.remove(0);
                    dataXString.remove(0);
                    dataY.add(dataRecent);
                    dataX.add(dataX.get(dataX.size()-1)+1);
                    dataXString.add(((Float)(dataX.get(dataX.size()-1)+1)).toString());
                    dataYString.add(dataRecent.toString());

                    error=0;
                    return json2.getString(TAG_MESSAGE);

                }
                else
                {
                    Log.d("Data Failure!", json.getString(TAG_MESSAGE));
                    return json.getString(TAG_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error de conexión con el servidor!";
            }

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String file_url)
        {
            // dismiss the dialog once product deleted
            if (file_url != null && !file_url.isEmpty() && !file_url.contains("correcto") && error==0) {
                error=1;
                Toast.makeText(GraficoParametro.this, file_url, Toast.LENGTH_SHORT).show();
            }
        }


    }

    @Override
    public void onBackPressed() {
        Intent n_act=new Intent(this,Parametros.class);
        n_act.putExtra("noCama",camaId);
        n_act.putExtra("noSector",sectorId);
        startActivity(n_act);
    }
}
