package com.uci.user.ari;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import org.apache.http.message.*;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    //private final String serverUrl = "http://190.155.112.105:443/caidaAlarm.php";
    private final String serverUrl = "http://190.155.112.105:443/";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private String enteredUsername, enteredPassword;
    private EditText username,password;

    private JSONParser jsonParser = new JSONParser();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPref = MainActivity.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        String nombre=sharedPref.getString(getString(R.string.data_nombre),"");
        if(!nombre.isEmpty())
        {
            //GENERA LA NOTIFICACION QUE NUNCA SE QUITA
            NotificationCompat.Builder mBuilder;
            NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

            int icono = R.drawable.icon_b;
            Intent n_activity=new Intent(MainActivity.this, Sectores.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 0, n_activity, 0);

            mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(icono)
                    //ESTO HACE QUE LA NOTIFICACION NO PUEDA SER ELIMINADA
                    .setOngoing(true)
                    .setContentTitle(getText(R.string.title_notificacion_permanente))
                    .setContentText(getText(R.string.message_notificacion_permanente))
                    .setAutoCancel(false)
                    .setColor(0xFF00FF00)
                    .setOnlyAlertOnce(true);

            //EL ID DE LA NOTIFICACION NO SE PUEDE REPETIR O SINO SE REEMPLAZA
            mNotifyMgr.notify(1, mBuilder.build());

            String apellido=sharedPref.getString(getString(R.string.data_apellido),"");
            int rol=sharedPref.getInt(getString(R.string.data_rol),0);

            n_activity.putExtra(getString(R.string.data_rol), rol);
            n_activity.putExtra(getString(R.string.data_nombre),nombre);
            n_activity.putExtra(getString(R.string.data_apellido),apellido );
            startActivity(n_activity);
        }

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button b_login=findViewById(R.id.login);
        username=findViewById(R.id.usuario);
        password=findViewById(R.id.password);
        b_login.setOnClickListener(loginListener);

    }


    private void scheduleAlarm() {
        // Construct an intent that will execute the AlarmReceiver
        Intent intent = new Intent(getApplicationContext(), StatusAlarmReceiver.class);

        // Create a PendingIntent to be triggered when the alarm goes off
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, StatusAlarmReceiver.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Setup periodic alarm every every half hour from this point onwards
        long firstMillis = System.currentTimeMillis(); // alarm is set right away
        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);

        // First parameter is the type: ELAPSED_REALTIME, ELAPSED_REALTIME_WAKEUP, RTC_WAKEUP
        // Interval can be INTERVAL_FIFTEEN_MINUTES, INTERVAL_HALF_HOUR, INTERVAL_HOUR, INTERVAL_DAY
        alarm.set(AlarmManager.RTC_WAKEUP, firstMillis, pIntent);
    }

    private View.OnClickListener loginListener = new View.OnClickListener()
    {
        public void onClick(View v) {
            // do something when the button is clicked

            enteredUsername = username.getText().toString();
            enteredPassword = password.getText().toString();

            if(enteredUsername.equals("") && enteredPassword.equals(""))
            {
                Toast.makeText(MainActivity.this, "Alerta: Campos vacíos!!", Toast.LENGTH_LONG).show();
                return;

            }
            else if(enteredUsername.equals(""))
            {
                Toast.makeText(MainActivity.this, "Alerta: Campo USUARIO vacío!!", Toast.LENGTH_LONG).show();
                return;
            }
            else if(enteredPassword.equals(""))
            {
                Toast.makeText(MainActivity.this, "Alerta: Campos CONTRASEÑA vacío!!", Toast.LENGTH_LONG).show();
                return;
            }
            new AttemptLogin().execute();

        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.logout) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch (id) {
            case R.id.nav_camera:
                // Handle the camera action
                break;
            case R.id.nav_gallery:

                break;
            case R.id.nav_slideshow:

                break;
            case R.id.nav_manage:

                break;
            case R.id.nav_share:

                break;
            case R.id.nav_send:

                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class AttemptLogin extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success;
            try {
                // Building Parameters
                List parametros = new ArrayList();
                parametros.add(new BasicNameValuePair("username", enteredUsername));
                parametros.add(new BasicNameValuePair("password", enteredPassword));
                //parametros.add(new BasicNameValuePair("paciente", "1"));

                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1)
                {
                    // GUARDO LOS DATOS DEL USUARIO
                    SharedPreferences sharedPref = MainActivity.this.getSharedPreferences(
                            getString(R.string.preferencs_file), Context.MODE_PRIVATE);
                    SharedPreferences.Editor edit = sharedPref.edit();

                    //INGRESO LOS DATOS AL ARCHIVO PARA LUEGO LEERLOS
                    //NOMBRE, VALOR
                    edit.putString(getString(R.string.data_nombre), json.getString("nombre"));
                    edit.putString(getString(R.string.data_apellido), json.getString("apellido"));
                    edit.putInt(getString(R.string.data_rol),json.getInt("rol"));
                    //edit.putInt(getString(R.string.data_alarm_sector)+"_"+"A",1);
                    edit.apply();

                    //GENERA LA NOTIFICACION QUE NUNCA SE QUITA
                    NotificationCompat.Builder mBuilder;
                    NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

                    int icono = R.drawable.icon_b;
                    Intent n_activity=new Intent(MainActivity.this, Sectores.class);
                    PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 0, n_activity, 0);

                    mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                            .setContentIntent(pendingIntent)
                            .setSmallIcon(icono)
                            //ESTO HACE QUE LA NOTIFICACION NO PUEDA SER ELIMINADA
                            .setOngoing(true)
                            .setContentTitle(getText(R.string.title_notificacion_permanente))
                            .setContentText(getText(R.string.message_notificacion_permanente))
                            .setAutoCancel(false)
                            .setColor(0xFF00FF00)
                            .setOnlyAlertOnce(true);

                    //EL ID DE LA NOTIFICACION NO SE PUEDE REPETIR O SINO SE REEMPLAZA
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        mBuilder.setChannelId("com.ARI");
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        NotificationChannel channel = new NotificationChannel(
                                "com.ARI",
                                "ARI",
                                NotificationManager.IMPORTANCE_DEFAULT
                        );
                        if (mNotifyMgr != null) {
                            mNotifyMgr.createNotificationChannel(channel);
                        }
                    }
                    mNotifyMgr.notify(1, mBuilder.build());

                    scheduleAlarm();
                    startActivity(n_activity);

                    //return json.getString(TAG_MESSAGE);
                    return json.getString("nombre");
                }
                else
                {
                    Log.d("Login Failure!", json.getString(TAG_MESSAGE));
                    return json.getString(TAG_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error de conexión con el servidor!";
            }

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String MensajeLogin)
        {
            // dismiss the dialog once product deleted
            if (MensajeLogin != null) {
                Toast.makeText(MainActivity.this, "Bienvenido: "+MensajeLogin, Toast.LENGTH_LONG).show();
            }
        }
    }
}
