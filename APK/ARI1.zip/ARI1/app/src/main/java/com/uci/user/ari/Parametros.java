package com.uci.user.ari;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Parametros extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Handler mHandler;
    private final String serverUrl = "http://190.155.112.105:443/bedRoomCheck.php";
    private final String patientUrl= "http://190.155.112.105:443/parameterData.php";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private JSONParser jsonParser = new JSONParser();

    private int sectorId=0,camaId=0;
    private String nombre_paciente;
    private int rol=3;
    private int error=0;
    private TextView insideTitle;
    private String title="Sector ",sector,cama;
    private boolean isCancelled=false;
    private ProgressDialog dialog;

    private String pr_text, hr_text, t_text, qt_text, qrsdur_text,qtc_text,p_text,qrs_text,rv5_text,sv1_text;
    private Button presion, hr, qt, temp, qrsdur,qtc,p,qrs,rv5,sv1;
    private int alertaPr=0, alertaHr=0, alertaT=0, alertaQt=0,alertaQsdur=0,alertaQtc=0,alertaP=0,alertaQrs=0,alertaRv5=0,alertaSv1=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_parametros);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        insideTitle=findViewById(R.id.txtSectores);

        this.mHandler = new Handler();
        this.mHandler.postDelayed(m_Runnable,500);

        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

        presion= findViewById(R.id.btnPar1);
        hr= findViewById(R.id.btnPar2);
        temp = findViewById(R.id.btnPar3);
        qt= findViewById(R.id.btnPar4);
        qrsdur = findViewById(R.id.btnPar5);
        qtc= findViewById(R.id.btnPar6);
        p= findViewById(R.id.btnPar7);
        qrs = findViewById(R.id.btnPar8);
        rv5= findViewById(R.id.btnPar9);
        sv1= findViewById(R.id.btnPar10);

        presion.setOnClickListener(parametroListener);
        hr.setOnClickListener(parametroListener);
        qt.setOnClickListener(parametroListener);
        temp.setOnClickListener(parametroListener);
        qrsdur.setOnClickListener(parametroListener);
        qtc.setOnClickListener(parametroListener);
        p.setOnClickListener(parametroListener);
        qrs.setOnClickListener(parametroListener);
        rv5.setOnClickListener(parametroListener);
        sv1.setOnClickListener(parametroListener);

        dialog=new ProgressDialog(Parametros.this);
        dialog.setMessage("Cargando...");
        dialog.setCancelable(false);
        dialog.setInverseBackgroundForced(false);
        dialog.show();

        SharedPreferences sharedPref = Parametros.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        rol = sharedPref.getInt(getString(R.string.data_rol),0);


        Bundle b=this.getIntent().getExtras();
        if(b!=null)
        {
            sectorId=b.getInt("noSector");
            camaId=b.getInt("noCama");
        }


        switch(sectorId)
        {
            case 0:
            {
                title+="A > ";
                sector="A";
                break;
            }
            case 1:
            {
                title+="B > ";
                sector="B";
                break;
            }
            case 2:
            {
                title+="C > ";
                sector="C";
                break;
            }
            case 3:
            {
                title+="D > ";
                sector="D";
                break;
            }
        }

        switch(camaId)
        {
            case R.id.secACama1:
            {
                title+="Cama 1";
                cama="1";
                break;
            }
            case R.id.secACama2:
            {
                title+="Cama 2";
                cama="2";
                break;
            }
            case R.id.secACama3:
            {
                title+="Cama 3";
                cama="3";
                break;
            }
            case R.id.secACama4:
            {
                title+="Cama 4";
                cama="4";
                break;
            }
            case R.id.secACama5:
            {
                title+="Cama 5";
                cama="5";
                break;
            }
            case R.id.secACama6:
            {
                title+="Cama 6";
                cama="6";
                break;
            }
            case R.id.secACama7:
            {
                title+="Cama 7";
                cama="7";
                break;
            }
            case R.id.secACama8:
            {
                title+="Cama 8";
                cama="8";
                break;
            }
            case R.id.secACama9:
            {
                title+="Cama 9";
                cama="9";
                break;
            }
            case R.id.secACama10:
            {
                title+="Cama 10";
                cama="10";
                break;
            }
            case R.id.secACama11:
            {
                title+="Cama 11";
                cama="11";
                break;
            }
            case R.id.secACama12:
            {
                title+="Cama 12";
                cama="12";
                break;
            }
        }

        alertaPr =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+1+"_"+cama+"_"+sector,0);
        alertaHr=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+2+"_"+cama+"_"+sector,0);
        alertaT=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+3+"_"+cama+"_"+sector,0);
        alertaQt=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+4+"_"+cama+"_"+sector,0);
        alertaQsdur =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+5+"_"+cama+"_"+sector,0);
        alertaQrs=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+6+"_"+cama+"_"+sector,0);
        alertaQtc=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+7+"_"+cama+"_"+sector,0);
        alertaRv5=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+8+"_"+cama+"_"+sector,0);
        alertaSv1 =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+9+"_"+cama+"_"+sector,0);
        alertaP=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+10+"_"+cama+"_"+sector,0);

        if (alertaPr == 1) {
            presion.setBackground(rojo);
            presion.setTextColor(Color.parseColor("#000000"));
        } else {
            presion.setBackground(verde);
            presion.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQt == 1) {
            qt.setBackground(rojo);
            qt.setTextColor(Color.parseColor("#000000"));
        } else {
            qt.setBackground(verde);
            qt.setTextColor(Color.parseColor("#4FC5D3"));

        }
        if (alertaT == 1) {
            temp.setBackground(rojo);
            temp.setTextColor(Color.parseColor("#000000"));
        } else {
            temp.setBackground(verde);
            temp.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaHr == 1) {
            hr.setBackground(rojo);
            hr.setTextColor(Color.parseColor("#000000"));
        } else {
            hr.setBackground(verde);
            hr.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQtc == 1) {
            qtc.setBackground(rojo);
            qtc.setTextColor(Color.parseColor("#000000"));
        } else {
            qtc.setBackground(verde);
            qtc.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQrs == 1) {
            qrs.setBackground(rojo);
            qrs.setTextColor(Color.parseColor("#000000"));
        } else {
            qrs.setBackground(verde);
            qrs.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQsdur == 1) {
            qrsdur.setBackground(rojo);
            qrsdur.setTextColor(Color.parseColor("#000000"));
        } else {
            qrsdur.setBackground(verde);
            qrsdur.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaP == 1) {
            p.setBackground(rojo);
            p.setTextColor(Color.parseColor("#000000"));
        } else {
            p.setBackground(verde);
            p.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaRv5 == 1) {
            rv5.setBackground(rojo);
            rv5.setTextColor(Color.parseColor("#000000"));
        } else {
            rv5.setBackground(verde);
            rv5.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaSv1 == 1) {
            sv1.setBackground(rojo);
            sv1.setTextColor(Color.parseColor("#000000"));
        } else {
            sv1.setBackground(verde);
            sv1.setTextColor(Color.parseColor("#4FC5D3"));
        }

        new AttemptPatientData().execute();

        setTitle(title);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    protected void onStop() {
        this.mHandler.removeCallbacks(this.m_Runnable);
        isCancelled=true;
        super.onStop();
    }

    @Override
    protected void onPause() {
        isCancelled=true;
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isCancelled=false;
        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

        new AttemptPatientData().execute();

        SharedPreferences sharedPref = Parametros.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        rol = sharedPref.getInt(getString(R.string.data_rol),0);

        alertaPr =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+1+"_"+cama+"_"+sector,0);
        alertaHr=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+2+"_"+cama+"_"+sector,0);
        alertaT=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+3+"_"+cama+"_"+sector,0);
        alertaQt=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+4+"_"+cama+"_"+sector,0);
        alertaQsdur =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+5+"_"+cama+"_"+sector,0);
        alertaQrs=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+6+"_"+cama+"_"+sector,0);
        alertaQtc=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+7+"_"+cama+"_"+sector,0);
        alertaRv5=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+8+"_"+cama+"_"+sector,0);
        alertaSv1 =sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+9+"_"+cama+"_"+sector,0);
        alertaP=sharedPref.getInt(getString(R.string.data_par_cam_sec)+"_"+10+"_"+cama+"_"+sector,0);

        if (alertaPr == 1) {
            presion.setBackground(rojo);
            presion.setTextColor(Color.parseColor("#000000"));
        } else {
            presion.setBackground(verde);
            presion.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQt == 1) {
            qt.setBackground(rojo);
            qt.setTextColor(Color.parseColor("#000000"));
        } else {
            qt.setBackground(verde);
            qt.setTextColor(Color.parseColor("#4FC5D3"));

        }
        if (alertaT == 1) {
            temp.setBackground(rojo);
            temp.setTextColor(Color.parseColor("#000000"));
        } else {
            temp.setBackground(verde);
            temp.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaHr == 1) {
            hr.setBackground(rojo);
            hr.setTextColor(Color.parseColor("#000000"));
        } else {
            hr.setBackground(verde);
            hr.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQtc == 1) {
            qtc.setBackground(rojo);
            qtc.setTextColor(Color.parseColor("#000000"));
        } else {
            qtc.setBackground(verde);
            qtc.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQrs == 1) {
            qrs.setBackground(rojo);
            qrs.setTextColor(Color.parseColor("#000000"));
        } else {
            qrs.setBackground(verde);
            qrs.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaQsdur == 1) {
            qrsdur.setBackground(rojo);
            qrsdur.setTextColor(Color.parseColor("#000000"));
        } else {
            qrsdur.setBackground(verde);
            qrsdur.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaP == 1) {
            p.setBackground(rojo);
            p.setTextColor(Color.parseColor("#000000"));
        } else {
            p.setBackground(verde);
            p.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaRv5 == 1) {
            rv5.setBackground(rojo);
            rv5.setTextColor(Color.parseColor("#000000"));
        } else {
            rv5.setBackground(verde);
            rv5.setTextColor(Color.parseColor("#4FC5D3"));
        }
        if (alertaSv1 == 1) {
            sv1.setBackground(rojo);
            sv1.setTextColor(Color.parseColor("#000000"));
        } else {
            sv1.setBackground(verde);
            sv1.setTextColor(Color.parseColor("#4FC5D3"));
        }
        Parametros.this.mHandler.postDelayed(m_Runnable, 500);
    }

    private final Runnable m_Runnable = new Runnable()
    {
        public void run()

        {
            Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
            Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

            new AttemptPatientData().execute();

            SharedPreferences sharedPref = Parametros.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            rol = sharedPref.getInt(getString(R.string.data_rol),0);

            int chequeado = sharedPref.getInt("chequeado",0);

            if(chequeado==1) {
                alertaPr = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 1 + "_" + cama + "_" + sector, 0);
                alertaHr = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 2 + "_" + cama + "_" + sector, 0);
                alertaT = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 3 + "_" + cama + "_" + sector, 0);
                alertaQt = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 4 + "_" + cama + "_" + sector, 0);
                alertaQsdur = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 5 + "_" + cama + "_" + sector, 0);
                alertaQrs = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 6 + "_" + cama + "_" + sector, 0);
                alertaQtc = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 7 + "_" + cama + "_" + sector, 0);
                alertaRv5 = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 8 + "_" + cama + "_" + sector, 0);
                alertaSv1 = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 9 + "_" + cama + "_" + sector, 0);
                alertaP = sharedPref.getInt(getString(R.string.data_par_cam_sec) + "_" + 10 + "_" + cama + "_" + sector, 0);

                if (alertaPr == 1) {
                    presion.setBackground(rojo);
                    presion.setTextColor(Color.parseColor("#000000"));
                } else {
                    presion.setBackground(verde);
                    presion.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaQt == 1) {
                    qt.setBackground(rojo);
                    qt.setTextColor(Color.parseColor("#000000"));
                } else {
                    qt.setBackground(verde);
                    qt.setTextColor(Color.parseColor("#4FC5D3"));

                }
                if (alertaT == 1) {
                    temp.setBackground(rojo);
                    temp.setTextColor(Color.parseColor("#000000"));
                } else {
                    temp.setBackground(verde);
                    temp.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaHr == 1) {
                    hr.setBackground(rojo);
                    hr.setTextColor(Color.parseColor("#000000"));
                } else {
                    hr.setBackground(verde);
                    hr.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaQtc == 1) {
                    qtc.setBackground(rojo);
                    qtc.setTextColor(Color.parseColor("#000000"));
                } else {
                    qtc.setBackground(verde);
                    qtc.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaQrs == 1) {
                    qrs.setBackground(rojo);
                    qrs.setTextColor(Color.parseColor("#000000"));
                } else {
                    qrs.setBackground(verde);
                    qrs.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaQsdur == 1) {
                    qrsdur.setBackground(rojo);
                    qrsdur.setTextColor(Color.parseColor("#000000"));
                } else {
                    qrsdur.setBackground(verde);
                    qrsdur.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaP == 1) {
                    p.setBackground(rojo);
                    p.setTextColor(Color.parseColor("#000000"));
                } else {
                    p.setBackground(verde);
                    p.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaRv5 == 1) {
                    rv5.setBackground(rojo);
                    rv5.setTextColor(Color.parseColor("#000000"));
                } else {
                    rv5.setBackground(verde);
                    rv5.setTextColor(Color.parseColor("#4FC5D3"));
                }
                if (alertaSv1 == 1) {
                    sv1.setBackground(rojo);
                    sv1.setTextColor(Color.parseColor("#000000"));
                } else {
                    sv1.setBackground(verde);
                    sv1.setTextColor(Color.parseColor("#4FC5D3"));
                }
            }
            Parametros.this.mHandler.postDelayed(m_Runnable, 500);
        }

    };

    private View.OnClickListener parametroListener= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent n_activity=new Intent(view.getContext(),GraficoParametro.class);

            n_activity.putExtra("noSector",sectorId);
            n_activity.putExtra("noCama",camaId);
            n_activity.putExtra("noParameter",view.getId());
            startActivity(n_activity);
        }
    };


    private class AttemptPatientData extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success;
            if(isCancelled)
            {
                return "correcto";
            }
            try {

                List parametros = new ArrayList();
                parametros.add(new BasicNameValuePair("cama", title.substring(title.lastIndexOf("a")+1).trim()));
                parametros.add(new BasicNameValuePair("sector", title.substring(title.lastIndexOf("r")+1,title.indexOf(">")).trim()));

                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1)
                {
                    nombre_paciente=json.getString("apellido")+" "+json.getString("nombre");


                    parametros = new ArrayList();
                    parametros.add(new BasicNameValuePair("id", json.getString("PatientIID")));

                    // getting product details by making HTTP request
                    JSONObject json2 = jsonParser.makeHttpRequest(patientUrl, "POST", parametros);
                    pr_text=json2.getString("PR");
                    hr_text=json2.getString("HR");
                    t_text=json2.getString("T");
                    qt_text=json2.getString("QT");
                    sv1_text=json2.getString("SV1");
                    rv5_text=json2.getString("RV5");
                    qtc_text=json2.getString("QTC");
                    qrsdur_text =json2.getString("QRSDUR");
                    qrs_text=json2.getString("QRS");
                    p_text=json2.getString("P");

                    Parametros.this.runOnUiThread(new Runnable() {
                        public void run()
                        {
                            insideTitle.setText(nombre_paciente);
                            presion.setText(pr_text);
                            hr.setText(hr_text);
                            temp.setText(t_text);
                            qtc.setText(qtc_text);
                            qt.setText(qt_text);
                            qrs.setText(qrs_text);
                            qrsdur.setText(qrsdur_text);
                            p.setText(p_text);
                            rv5.setText(rv5_text);
                            sv1.setText(sv1_text);
                        }
                    });
                    error=0;
                    return json2.getString(TAG_MESSAGE);

                }
                else
                {
                    Log.d("Data Failure!", json.getString(TAG_MESSAGE));
                    return json.getString(TAG_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error de conexión con el servidor!";
            }
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String file_url)
        {
            // dismiss the dialog once product deleted
            if (file_url != null && !file_url.isEmpty() && !file_url.contains("correcto") && error==0) {
                error=1;
                Toast.makeText(Parametros.this, file_url, Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        }


    }

    private void cancelAlarm() {
        Intent intent = new Intent(getApplicationContext(), StatusAlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, StatusAlarmReceiver.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Intent n_act=new Intent(this,Camas.class);
            n_act.putExtra("noCama",camaId);
            n_act.putExtra("noSector",sectorId);
            startActivity(n_act);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.parametros, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.logout) {
            SharedPreferences sharedPref = Parametros.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPref.edit();
            edit.clear();
            edit.apply();

            Intent serviceI = new Intent(Parametros.this, CheckStatusService.class);
            stopService(serviceI);

            NotificationCompat.Builder mBuilder;
            NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

            int icono = R.drawable.icon_b;
            Intent i=new Intent(Parametros.this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(Parametros.this, 0, i, 0);

            mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(icono)
                    .setContentTitle(getText(R.string.title_notificacion_logout))
                    .setContentText(getText(R.string.message_notificacion_logout))
                    .setAutoCancel(true)
                    .setColor(0xFF00FF00)
                    .setOnlyAlertOnce(true);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mBuilder.setChannelId("com.ARI");
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        "com.ARI",
                        "ARI",
                        NotificationManager.IMPORTANCE_DEFAULT
                );
                if (mNotifyMgr != null) {
                    mNotifyMgr.createNotificationChannel(channel);
                }
            }
            mNotifyMgr.notify(1, mBuilder.build());

            cancelAlarm();

            Intent n_activity=new Intent(Parametros.this,MainActivity.class);
            startActivity(n_activity);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        int sector=0;
        Intent n_activity=new Intent(this,Camas.class);
        if (id == R.id.nav_send) {

        }
        else{
            switch (id) {
                case R.id.nav_sector_b:
                    sector = 1;
                    break;
                case R.id.nav_sector_c:
                    sector = 2;
                    break;
                case R.id.nav_sector_d:
                    sector = 3;
                    break;
            }
            n_activity.putExtra("noSector",sector);
            startActivity(n_activity);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
