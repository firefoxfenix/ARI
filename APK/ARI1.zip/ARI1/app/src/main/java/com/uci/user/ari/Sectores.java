package com.uci.user.ari;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;

public class Sectores extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private String nombre,apellido;
    private int rol=3;
    private int alertaA=0, alertaB=0, alertaC=0, alertaD=0;
    private Handler mHandler;
    private ArrayList<Integer> camas=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sectores);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        this.mHandler = new Handler();
        this.mHandler.postDelayed(m_Runnable,500);

        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

        Drawable sec1a = getResources().getDrawable(R.drawable.sec1a);
        Drawable sec1n = getResources().getDrawable(R.drawable.sec1n);
        Drawable sec2a = getResources().getDrawable(R.drawable.sec2a);
        Drawable sec2n = getResources().getDrawable(R.drawable.sec2n);
        Drawable sec3a = getResources().getDrawable(R.drawable.sec3a);
        Drawable sec3n = getResources().getDrawable(R.drawable.sec3n);
        Drawable sec4a = getResources().getDrawable(R.drawable.sec4a);
        Drawable sec4n = getResources().getDrawable(R.drawable.sec4n);

        camas.add(R.id.secACama1);
        camas.add(R.id.secACama2);
        camas.add(R.id.secACama3);
        camas.add(R.id.secACama4);
        camas.add(R.id.secACama5);
        camas.add(R.id.secACama6);
        camas.add(R.id.secACama7);
        camas.add(R.id.secACama8);
        camas.add(R.id.secACama9);
        camas.add(R.id.secACama10);
        camas.add(R.id.secACama11);
        camas.add(R.id.secACama12);
        camas.add(R.id.secACama13);
        camas.add(R.id.secACama14);

        int h = sec1a.getIntrinsicHeight();
        int w = sec1a.getIntrinsicWidth();
        sec1a.setBounds( 0, 0, w, h );
        sec1n.setBounds( 0, 0, w, h );
        sec2a.setBounds( 0, 0, w, h );
        sec2n.setBounds( 0, 0, w, h );
        sec3a.setBounds( 0, 0, w, h );
        sec3n.setBounds( 0, 0, w, h );
        sec4a.setBounds( 0, 0, w, h );
        sec4n.setBounds( 0, 0, w, h );

        //LEO LOS DATOS DEL ARCHIVO
        SharedPreferences sharedPref = Sectores.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);

        //BUSCA LOS DATOS POR
        //NOMBRE,VALOR
        //AQUI DEBERIAS TAMBIEN BUSCAR LOS DATOS DE SECTOR_#SECTOR Y PREGUNTAR SI ES
        //(0 VERDE,1 ROJO)
        nombre = sharedPref.getString(getString(R.string.data_nombre),"");
        apellido = sharedPref.getString(getString(R.string.data_apellido),"");
        rol = sharedPref.getInt(getString(R.string.data_rol),0);

        //SI NO EXISTEN DATOS EN EL ARCHIVO TE INICIA EL LOGIN
        if(nombre.isEmpty())
        {
            Intent n_activity=new Intent(Sectores.this,MainActivity.class);
            startActivity(n_activity);
        }

        Button b_secA= findViewById(R.id.btnSectorA);
        Button b_secB= findViewById(R.id.btnSectorB);
        Button b_secC= findViewById(R.id.btnSectorC);
        Button b_secD= findViewById(R.id.btnSectorD);

        alertaA = sharedPref.getInt(getString(R.string.data_alarm_sector)+"_"+"A",0);
        alertaB = sharedPref.getInt(getString(R.string.data_alarm_sector)+"_"+"B",0);
        alertaC = sharedPref.getInt(getString(R.string.data_alarm_sector)+"_"+"C",0);
        alertaD = sharedPref.getInt(getString(R.string.data_alarm_sector)+"_"+"D",0);

        if (alertaA==1)
        {
            b_secA.setBackground(rojo);
            b_secA.setTextColor(Color.parseColor("#000000"));
            b_secA.setCompoundDrawables(null,null,null, sec1n);
            b_secA.setPadding(0,0,0,100);
            b_secA.setCompoundDrawablePadding(-100);
        }
        else
        {
            b_secA.setBackground(verde);
            b_secA.setTextColor(Color.parseColor("#4FC5D3"));
            b_secA.setCompoundDrawables(null,null,null, sec1a);
            b_secA.setPadding(0,0,0,100);
            b_secA.setCompoundDrawablePadding(-100);
        }
        if (alertaB==1)
        {
            b_secB.setBackground(rojo);
            b_secB.setTextColor(Color.parseColor("#000000"));
            b_secB.setCompoundDrawables(null,null,null, sec2n);
            b_secB.setPadding(0,0,0,100);
            b_secB.setCompoundDrawablePadding(-100);
        }
        else
        {
            b_secB.setBackground(verde);
            b_secB.setTextColor(Color.parseColor("#4FC5D3"));
            b_secB.setCompoundDrawables(null,null,null, sec2a);
            b_secB.setPadding(0,0,0,100);
            b_secB.setCompoundDrawablePadding(-100);
        }
        if (alertaC==1)
        {
            b_secC.setBackground(rojo);
            b_secC.setTextColor(Color.parseColor("#000000"));
            b_secC.setCompoundDrawables(null,null,null, sec3n);
            b_secC.setPadding(0,0,0,100);
            b_secC.setCompoundDrawablePadding(-100);
        }
        else
        {
            b_secC.setBackground(verde);
            b_secC.setTextColor(Color.parseColor("#4FC5D3"));
            b_secC.setCompoundDrawables(null,null,null, sec3a);
            b_secC.setPadding(0,0,0,100);
            b_secC.setCompoundDrawablePadding(-100);
        }
        if (alertaD==1)
        {
            b_secD.setBackground(rojo);
            b_secD.setTextColor(Color.parseColor("#000000"));
            b_secD.setCompoundDrawables(null,null,null, sec4n);
            b_secD.setPadding(0,0,0,100);
            b_secD.setCompoundDrawablePadding(-100);
        }
        else
        {
            b_secD.setBackground(verde);
            b_secD.setTextColor(Color.parseColor("#4FC5D3"));
            b_secD.setCompoundDrawables(null,null,null, sec4a);
            b_secD.setPadding(0,0,0,100);
            b_secD.setCompoundDrawablePadding(-100);
        }

        b_secA.setOnClickListener(sectorListener);
        b_secB.setOnClickListener(sectorListener);
        b_secC.setOnClickListener(sectorListener);
        b_secD.setOnClickListener(sectorListener);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    protected void onResume() {
        SharedPreferences sharedPref = Sectores.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        rol = sharedPref.getInt(getString(R.string.data_rol),0);
        int chequeado = sharedPref.getInt("chequeado",0);

        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

        Drawable sec1a = getResources().getDrawable(R.drawable.sec1a);
        Drawable sec1n = getResources().getDrawable(R.drawable.sec1n);
        Drawable sec2a = getResources().getDrawable(R.drawable.sec2a);
        Drawable sec2n = getResources().getDrawable(R.drawable.sec2n);
        Drawable sec3a = getResources().getDrawable(R.drawable.sec3a);
        Drawable sec3n = getResources().getDrawable(R.drawable.sec3n);
        Drawable sec4a = getResources().getDrawable(R.drawable.sec4a);
        Drawable sec4n = getResources().getDrawable(R.drawable.sec4n);

        int h = sec1a.getIntrinsicHeight();
        int w = sec1a.getIntrinsicWidth();
        sec1a.setBounds(0, 0, w, h);
        sec1n.setBounds(0, 0, w, h);
        sec2a.setBounds(0, 0, w, h);
        sec2n.setBounds(0, 0, w, h);
        sec3a.setBounds(0, 0, w, h);
        sec3n.setBounds(0, 0, w, h);
        sec4a.setBounds(0, 0, w, h);
        sec4n.setBounds(0, 0, w, h);

        int cCeleste = getResources().getColor(R.color.letras);
        int cNegro = getResources().getColor(R.color.letras2);


        //SECTORES
        Button b_secA = findViewById(R.id.btnSectorA);
        Button b_secB = findViewById(R.id.btnSectorB);
        Button b_secC = findViewById(R.id.btnSectorC);
        Button b_secD = findViewById(R.id.btnSectorD);

        alertaA = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "A", 0);
        alertaB = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "B", 0);
        alertaC = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "C", 0);
        alertaD = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "D", 0);

        if (alertaA == 1) {
            b_secA.setBackground(rojo);
            b_secA.setTextColor(Color.parseColor("#000000"));
            b_secA.setCompoundDrawables(null, null, null, sec1n);
            b_secA.setPadding(0, 0, 0, 100);
            b_secA.setCompoundDrawablePadding(-100);
        } else {
            b_secA.setBackground(verde);
            b_secA.setTextColor(Color.parseColor("#4FC5D3"));
            b_secA.setCompoundDrawables(null, null, null, sec1a);
            b_secA.setPadding(0, 0, 0, 100);
            b_secA.setCompoundDrawablePadding(-100);
        }
        if (alertaB == 1) {
            b_secB.setBackground(rojo);
            b_secB.setTextColor(Color.parseColor("#000000"));
            b_secB.setCompoundDrawables(null, null, null, sec2n);
            b_secB.setPadding(0, 0, 0, 100);
            b_secB.setCompoundDrawablePadding(-100);
        } else {
            b_secB.setBackground(verde);
            b_secB.setTextColor(Color.parseColor("#4FC5D3"));
            b_secB.setCompoundDrawables(null, null, null, sec2a);
            b_secB.setPadding(0, 0, 0, 100);
            b_secB.setCompoundDrawablePadding(-100);
        }
        if (alertaC == 1) {
            b_secC.setBackground(rojo);
            b_secC.setTextColor(Color.parseColor("#000000"));
            b_secC.setCompoundDrawables(null, null, null, sec3n);
            b_secC.setPadding(0, 0, 0, 100);
            b_secC.setCompoundDrawablePadding(-100);
        } else {
            b_secC.setBackground(verde);
            b_secC.setTextColor(Color.parseColor("#4FC5D3"));
            b_secC.setCompoundDrawables(null, null, null, sec3a);
            b_secC.setPadding(0, 0, 0, 100);
            b_secC.setCompoundDrawablePadding(-100);
        }
        if (alertaD == 1) {
            b_secD.setBackground(rojo);
            b_secD.setTextColor(Color.parseColor("#000000"));
            b_secD.setCompoundDrawables(null, null, null, sec4n);
            b_secD.setPadding(0, 0, 0, 100);
            b_secD.setCompoundDrawablePadding(-100);
        } else {
            b_secD.setBackground(verde);
            b_secD.setTextColor(Color.parseColor("#4FC5D3"));
            b_secD.setCompoundDrawables(null, null, null, sec4a);
            b_secD.setPadding(0, 0, 0, 100);
            b_secD.setCompoundDrawablePadding(-100);
        }

        Sectores.this.mHandler.postDelayed(m_Runnable, 500);
        super.onResume();
    }

    @Override
    protected void onStop() {
        this.mHandler.removeCallbacks(this.m_Runnable);
        super.onStop();

    }

    private final Runnable m_Runnable = new Runnable()
    {
        public void run()

        {
            SharedPreferences sharedPref = Sectores.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            rol = sharedPref.getInt(getString(R.string.data_rol),0);
            int chequeado = sharedPref.getInt("chequeado",0);

            if(chequeado==1) {

                Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
                Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

                Drawable sec1a = getResources().getDrawable(R.drawable.sec1a);
                Drawable sec1n = getResources().getDrawable(R.drawable.sec1n);
                Drawable sec2a = getResources().getDrawable(R.drawable.sec2a);
                Drawable sec2n = getResources().getDrawable(R.drawable.sec2n);
                Drawable sec3a = getResources().getDrawable(R.drawable.sec3a);
                Drawable sec3n = getResources().getDrawable(R.drawable.sec3n);
                Drawable sec4a = getResources().getDrawable(R.drawable.sec4a);
                Drawable sec4n = getResources().getDrawable(R.drawable.sec4n);

                int h = sec1a.getIntrinsicHeight();
                int w = sec1a.getIntrinsicWidth();
                sec1a.setBounds(0, 0, w, h);
                sec1n.setBounds(0, 0, w, h);
                sec2a.setBounds(0, 0, w, h);
                sec2n.setBounds(0, 0, w, h);
                sec3a.setBounds(0, 0, w, h);
                sec3n.setBounds(0, 0, w, h);
                sec4a.setBounds(0, 0, w, h);
                sec4n.setBounds(0, 0, w, h);

                int cCeleste = getResources().getColor(R.color.letras);
                int cNegro = getResources().getColor(R.color.letras2);


                //SECTORES
                Button b_secA = findViewById(R.id.btnSectorA);
                Button b_secB = findViewById(R.id.btnSectorB);
                Button b_secC = findViewById(R.id.btnSectorC);
                Button b_secD = findViewById(R.id.btnSectorD);

                alertaA = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "A", 0);
                alertaB = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "B", 0);
                alertaC = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "C", 0);
                alertaD = sharedPref.getInt(getString(R.string.data_alarm_sector) + "_" + "D", 0);

                if (alertaA == 1) {
                    b_secA.setBackground(rojo);
                    b_secA.setTextColor(Color.parseColor("#000000"));
                    b_secA.setCompoundDrawables(null, null, null, sec1n);
                    b_secA.setPadding(0, 0, 0, 100);
                    b_secA.setCompoundDrawablePadding(-100);
                } else {
                    b_secA.setBackground(verde);
                    b_secA.setTextColor(Color.parseColor("#4FC5D3"));
                    b_secA.setCompoundDrawables(null, null, null, sec1a);
                    b_secA.setPadding(0, 0, 0, 100);
                    b_secA.setCompoundDrawablePadding(-100);
                }
                if (alertaB == 1) {
                    b_secB.setBackground(rojo);
                    b_secB.setTextColor(Color.parseColor("#000000"));
                    b_secB.setCompoundDrawables(null, null, null, sec2n);
                    b_secB.setPadding(0, 0, 0, 100);
                    b_secB.setCompoundDrawablePadding(-100);
                } else {
                    b_secB.setBackground(verde);
                    b_secB.setTextColor(Color.parseColor("#4FC5D3"));
                    b_secB.setCompoundDrawables(null, null, null, sec2a);
                    b_secB.setPadding(0, 0, 0, 100);
                    b_secB.setCompoundDrawablePadding(-100);
                }
                if (alertaC == 1) {
                    b_secC.setBackground(rojo);
                    b_secC.setTextColor(Color.parseColor("#000000"));
                    b_secC.setCompoundDrawables(null, null, null, sec3n);
                    b_secC.setPadding(0, 0, 0, 100);
                    b_secC.setCompoundDrawablePadding(-100);
                } else {
                    b_secC.setBackground(verde);
                    b_secC.setTextColor(Color.parseColor("#4FC5D3"));
                    b_secC.setCompoundDrawables(null, null, null, sec3a);
                    b_secC.setPadding(0, 0, 0, 100);
                    b_secC.setCompoundDrawablePadding(-100);
                }
                if (alertaD == 1) {
                    b_secD.setBackground(rojo);
                    b_secD.setTextColor(Color.parseColor("#000000"));
                    b_secD.setCompoundDrawables(null, null, null, sec4n);
                    b_secD.setPadding(0, 0, 0, 100);
                    b_secD.setCompoundDrawablePadding(-100);
                } else {
                    b_secD.setBackground(verde);
                    b_secD.setTextColor(Color.parseColor("#4FC5D3"));
                    b_secD.setCompoundDrawables(null, null, null, sec4a);
                    b_secD.setPadding(0, 0, 0, 100);
                    b_secD.setCompoundDrawablePadding(-100);
                }
            }
            Sectores.this.mHandler.postDelayed(m_Runnable, 500);
        }

    };

    private void cancelAlarm() {
        Intent intent = new Intent(getApplicationContext(), StatusAlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, StatusAlarmReceiver.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    private View.OnClickListener sectorListener= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent n_activity=new Intent(view.getContext(),Camas.class);
            int sector=0;
            switch (view.getId()){
                case R.id.btnSectorB:
                    sector=1;


                    break;
                case R.id.btnSectorC:
                    sector=2;
                    break;
                case R.id.btnSectorD:
                    sector=3;
                    break;
            }
            n_activity.putExtra("noSector",sector);
            startActivity(n_activity);
        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            //Intent n_act=new Intent(this,MainActivity.class);
            //startActivity(n_act);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.sectores, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.logout) {
            SharedPreferences sharedPref = Sectores.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPref.edit();
            edit.clear();
            edit.apply();

            Intent serviceI = new Intent(Sectores.this, CheckStatusService.class);
            stopService(serviceI);

            NotificationCompat.Builder mBuilder;
            NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

            int icono = R.drawable.icon_b;
            Intent i=new Intent(Sectores.this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(Sectores.this, 0, i, 0);

            mBuilder =new NotificationCompat.Builder(getApplicationContext(),"ARI")
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(icono)
                    .setContentTitle(getText(R.string.title_notificacion_logout))
                    .setContentText(getText(R.string.message_notificacion_logout))
                    .setAutoCancel(true)
                    .setColor(0xFF00FF00)
                    .setOnlyAlertOnce(true);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mBuilder.setChannelId("com.ARI");
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        "com.ARI",
                        "ARI",
                        NotificationManager.IMPORTANCE_DEFAULT
                );
                if (mNotifyMgr != null) {
                    mNotifyMgr.createNotificationChannel(channel);
                }
            }
            mNotifyMgr.notify(1, mBuilder.build());

            cancelAlarm();
            stopService(new Intent(this, CheckStatusService.class));

            Intent n_activity=new Intent(Sectores.this,MainActivity.class);
            startActivity(n_activity);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        int sector=0;
        Intent n_activity=new Intent(this,Camas.class);
        if (id == R.id.nav_send) {

        }
        else{
            switch (id) {
                case R.id.nav_sector_b:
                    sector = 1;
                    break;
                case R.id.nav_sector_c:
                    sector = 2;
                    break;
                case R.id.nav_sector_d:
                    sector = 3;
                    break;
            }
            n_activity.putExtra("noSector",sector);
            startActivity(n_activity);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
