package com.uci.user.ari;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.view.LineChartView;

public class GraficoTendencias extends AppCompatActivity {

    private final String serverUrl = "http://190.155.112.105:443/bedRoomCheck.php";
    private final String patientUrl= "http://190.155.112.105:443/parameterTendence.php";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private JSONParser jsonParser = new JSONParser();

    private int sectorId=0,camaId=0,parametroId=0,paraNum=1;
    private int error=0,j=0;
    private String title="Sector ";
    private String nombre_paciente,parametro;
    private int rol=3;
    private String dat1, dat2, dat3;
    private String dia1,dia2,dia3;
    private TextView insideTitle;
    private ProgressDialog dialog;

    private LineChartView lineChartView;

    private ArrayList<String> yAxisData=new ArrayList<>();

    private List<Float> xAxisValues1 = new ArrayList<Float>();
    private List<String> xAxisValues2 = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_grafico_tendencias);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        SharedPreferences sharedPref = GraficoTendencias.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        rol = sharedPref.getInt(getString(R.string.data_rol),0);

        dialog=new ProgressDialog(GraficoTendencias.this);
        dialog.setMessage("Cargando...");
        dialog.setCancelable(false);
        dialog.setInverseBackgroundForced(false);
        dialog.show();

        Bundle b=this.getIntent().getExtras();
        if(b!=null)
        {
            sectorId=b.getInt("noSector");
            camaId=b.getInt("noCama");
            parametroId=b.getInt("noParameter");
        }

        switch(sectorId)
        {
            case 0:
            {
                title+="A > ";
                break;
            }
            case 1:
            {
                title+="B > ";
                break;
            }
            case 2:
            {
                title+="C > ";
                break;
            }
            case 3:
            {
                title+="D > ";
                break;
            }
        }

        switch(camaId)
        {
            case R.id.secACama1:
            {
                title+="Cama 1";
                break;
            }
            case R.id.secACama2:
            {
                title+="Cama 2";
                break;
            }
            case R.id.secACama3:
            {
                title+="Cama 3";
                break;
            }
            case R.id.secACama4:
            {
                title+="Cama 4";
                break;
            }
            case R.id.secACama5:
            {
                title+="Cama 5";
                break;
            }
            case R.id.secACama6:
            {
                title+="Cama 6";
                break;
            }
            case R.id.secACama7:
            {
                title+="Cama 7";
                break;
            }
            case R.id.secACama8:
            {
                title+="Cama 8";
                break;
            }
            case R.id.secACama9:
            {
                title+="Cama 9";
                break;
            }
            case R.id.secACama10:
            {
                title+="Cama 10";
                break;
            }
            case R.id.secACama11:
            {
                title+="Cama 11";
                break;
            }
            case R.id.secACama12:
            {
                title+="Cama 12";
                break;
            }
        }

        switch(parametroId)
        {
            case R.id.btnPar1:
            {

                title+="> Presión";
                parametro="Presión";
                break;
            }
            case R.id.btnPar2:
            {
                title+="> Frec.";
                parametro="Frecuencia Cardiaca(lpm)";
                paraNum=2;
                break;
            }
            case R.id.btnPar3:
            {
                title+="> Temp.";
                parametro="Temperatura(C)";
                paraNum=3;
                break;
            }
            case R.id.btnPar4:
            {
                title+="> Oxig.";
                parametro="Oxigenación(%)";
                paraNum=4;
                break;
            }
            case R.id.btnPar5:
            {

                title+="> QRSDUR";
                parametro="QRSDUR";
                paraNum=5;
                break;
            }
            case R.id.btnPar6:
            {
                title+="> QTC.";
                parametro="QTC";
                paraNum=6;
                break;
            }
            case R.id.btnPar7:
            {
                title+="> Pulso";
                parametro="Pulso";
                paraNum=7;
                break;
            }
            case R.id.btnPar8:
            {
                title+="> QRS";
                parametro="QRS";
                paraNum=8;
                break;
            }
            case R.id.btnPar9:
            {
                title+="> RV5";
                parametro="RV5";
                paraNum=9;
                break;
            }
            case R.id.btnPar10:
            {
                title+="> SV1";
                parametro="SV1";
                paraNum=10;
                break;
            }
        }

        setTitle(title);

        new GraficoTendencias.AttemptPatientData().execute();

    }

    private class AttemptPatientData extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success;
            try {

                List parametros = new ArrayList();
                parametros.add(new BasicNameValuePair("cama", title.substring(title.lastIndexOf("a")+2,title.lastIndexOf("a")+3).trim()));
                parametros.add(new BasicNameValuePair("sector", title.substring(title.indexOf("r")+1,title.indexOf(">")).trim()));

                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1)
                {
                    nombre_paciente=json.getString("apellido")+" "+json.getString("nombre");


                    parametros = new ArrayList();
                    parametros.add(new BasicNameValuePair("id", json.getString("PatientIID")));
                    parametros.add(new BasicNameValuePair("parameter", Integer.toString(paraNum)));

                    // getting product details by making HTTP request
                    JSONObject json2 = jsonParser.makeHttpRequest(patientUrl, "POST", parametros);
                    dat1=json2.getString("y1");
                    dat2=json2.getString("y2");
                    dat3=json2.getString("y3");

                    dia1=json2.getString("x1");
                    dia2=json2.getString("x2");
                    dia3=json2.getString("x3");

                    GraficoTendencias.this.runOnUiThread(new Runnable() {
                        public void run()
                        {
                            yAxisData.add(dat1);
                            yAxisData.add(dat2);
                            yAxisData.add(dat3);

                            xAxisValues1.add(Float.parseFloat(dia1));
                            xAxisValues2.add(dia1);
                            xAxisValues1.add(Float.parseFloat(dia2));
                            xAxisValues2.add(dia2);
                            xAxisValues1.add(Float.parseFloat(dia3));
                            xAxisValues2.add(dia3);

                            lineChartView = findViewById(R.id.chart);

                            List yAxisValues = new ArrayList();

                            Line line = new Line(yAxisValues).setColor(Color.parseColor("#FFFFFF"));
                            line.setHasLabelsOnlyForSelected(true);

                            for (int i = 1; i <= yAxisData.size(); i++) {
                                yAxisValues.add(new PointValue(Integer.parseInt(dia1)-i+1, Float.parseFloat(yAxisData.get(i-1))));
                            }

                            List lines = new ArrayList();
                            lines.add(line);

                            LineChartData data = new LineChartData();
                            data.setLines(lines);
                            data.setValueLabelTextSize(35);
                            data.setValueLabelsTextColor(Color.CYAN);
                            data.setValueLabelBackgroundEnabled(false);
                            //data.setValueLabelBackgroundColor(Color.GRAY);

                            Axis axis = Axis.generateAxisFromCollection(xAxisValues1, xAxisValues2);
                            axis.setAutoGenerated(false);
                            axis.setTextSize(14);
                            axis.setName("Tiempo(Días)");
                            axis.setTextColor(Color.parseColor("#FFFFFF"));
                            data.setAxisXBottom(axis);

                            Axis yAxis = new Axis();
                            yAxis.setName(parametro);
                            yAxis.setTextColor(Color.parseColor("#FFFFFF"));
                            yAxis.setTextSize(14);
                            data.setAxisYLeft(yAxis);

                            lineChartView.setLineChartData(data);
                        }
                    });
                    error=0;
                    return json2.getString(TAG_MESSAGE);

                }
                else
                {
                    Log.d("Data Failure!", json.getString(TAG_MESSAGE));
                    return json.getString(TAG_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error de conexión con el servidor!";
            }

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String file_url)
        {
            // dismiss the dialog once product deleted
            if (file_url != null && !file_url.isEmpty() && !file_url.contains("correcto") && error==0) {
                error=1;
                Toast.makeText(GraficoTendencias.this, file_url, Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        }


    }

    @Override
    public void onBackPressed() {
        Intent n_act=new Intent(this,GraficoParametro.class);
        n_act.putExtra("noCama",camaId);
        n_act.putExtra("noSector",sectorId);
        n_act.putExtra("noParameter",parametroId);
        startActivity(n_act);
    }

}
