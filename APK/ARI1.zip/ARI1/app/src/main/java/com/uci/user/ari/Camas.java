package com.uci.user.ari;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Camas extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private int sector=0;
    private String title="Sector ";
    private Handler mHandler;
    private final String serverUrl = "http://190.155.112.105:443/bedRoomCheck.php";
    private final String patientUrl= "http://190.155.112.105:443/parameterData.php";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private JSONParser jsonParser = new JSONParser();

    private int sectorId=0,camaId=0;
    private String nombre_paciente;
    private int rol=3, error=0;
    private boolean isCancelled=false;
    private ProgressDialog dialog;


    private String nombre,apellido;
    private int buttonCounter=0;
    private int alertaA=0, alertaB=0, alertaC=0, alertaD=0;
    private ArrayList<Button> buttons=new ArrayList<>();
    private ArrayList<Integer> camas=new ArrayList<>();
    private ArrayList<String> camas_text=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camas);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        this.mHandler = new Handler();
        this.mHandler.postDelayed(m_Runnable,500);

        SharedPreferences sharedPref = Camas.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        nombre = sharedPref.getString(getString(R.string.data_nombre),"");
        apellido = sharedPref.getString(getString(R.string.data_apellido),"");
        rol = sharedPref.getInt(getString(R.string.data_rol),0);

        Button b_Cama1,b_Cama2,b_Cama3,b_Cama4,b_Cama5,b_Cama6,b_Cama7,b_Cama8,b_Cama9,b_Cama10,b_Cama11,b_Cama12,b_Cama13,b_Cama14;

        Bundle b=this.getIntent().getExtras();
        if(b!=null)
        {
            sector=b.getInt("noSector");
        }
        b_Cama1= findViewById(R.id.secACama1);
        b_Cama2= findViewById(R.id.secACama2);
        b_Cama3= findViewById(R.id.secACama3);
        b_Cama4= findViewById(R.id.secACama4);
        b_Cama5= findViewById(R.id.secACama5);
        b_Cama6= findViewById(R.id.secACama6);
        b_Cama7= findViewById(R.id.secACama7);


        b_Cama8= findViewById(R.id.secACama8);
        b_Cama9= findViewById(R.id.secACama9);
        b_Cama10= findViewById(R.id.secACama10);
        b_Cama11= findViewById(R.id.secACama11);
        b_Cama12= findViewById(R.id.secACama12);
        b_Cama13= findViewById(R.id.secACama13);
        b_Cama14= findViewById(R.id.secACama14);

        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);

        dialog=new ProgressDialog(Camas.this);
        dialog.setMessage("Cargando...");
        dialog.setCancelable(false);
        dialog.setInverseBackgroundForced(false);
        dialog.show();

        buttons.add(b_Cama1);
        buttons.add(b_Cama2);
        buttons.add(b_Cama3);
        buttons.add(b_Cama4);
        buttons.add(b_Cama5);
        buttons.add(b_Cama6);
        buttons.add(b_Cama7);
        buttons.add(b_Cama8);
        buttons.add(b_Cama9);
        buttons.add(b_Cama10);
        buttons.add(b_Cama11);
        buttons.add(b_Cama12);
        buttons.add(b_Cama13);
        buttons.add(b_Cama14);

        camas.add(R.id.secACama1);
        camas.add(R.id.secACama2);
        camas.add(R.id.secACama3);
        camas.add(R.id.secACama4);
        camas.add(R.id.secACama5);
        camas.add(R.id.secACama6);
        camas.add(R.id.secACama7);
        camas.add(R.id.secACama8);
        camas.add(R.id.secACama9);
        camas.add(R.id.secACama10);
        camas.add(R.id.secACama11);
        camas.add(R.id.secACama12);
        camas.add(R.id.secACama13);
        camas.add(R.id.secACama14);


        for (int i=0; i<14 && sector==0; i++)
        {
            alertaA = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"A",0);
            if (alertaA==1)
            {
                buttons.get(i).setBackground(rojo);
            }
            else
            {
                buttons.get(i).setBackground(verde);
            }
        }

        for (int i=0; i<14 && sector==1; i++)
        {
            alertaB = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"B",0);
            if (alertaB==1)
            {
                buttons.get(i).setBackground(rojo);
            }
            else
            {
                buttons.get(i).setBackground(verde);
            }
        }
        for (int i=0; i<14 && sector==2; i++)
        {
            alertaC = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"C",0);
            if (alertaC==1)
            {
                buttons.get(i).setBackground(rojo);
            }
            else
            {
                buttons.get(i).setBackground(verde);
            }
        }
        for (int i=0; i<14 && sector==3; i++)
        {
            alertaD = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"D",0);
            if (alertaD==1)
            {
                buttons.get(i).setBackground(rojo);
            }
            else
            {
                buttons.get(i).setBackground(verde);
            }
        }

        for(Button button:buttons)
        {
            button.setOnClickListener(camaButtonListener);
        }

        switch (sector)
        {
            case 0:
                title+= "A ";
                for (int i=7; i<14; i++)
                {
                    buttons.get(i).setEnabled(false);
                    buttons.get(i).setVisibility(View.INVISIBLE);
                }
                break;
            case 1:
                title+="B ";
                for (int i=7; i<14; i++)
                {
                    buttons.get(i).setEnabled(false);
                    buttons.get(i).setVisibility(View.INVISIBLE);
                }
                break;
            case 2:
                title+="C ";
                for (int i=7; i<14; i++)
                {
                    buttons.get(i).setEnabled(false);
                    buttons.get(i).setVisibility(View.INVISIBLE);
                }
                break;
            case 3:
                title+="D ";
                for (int i=12; i<14; i++)
                {
                    buttons.get(i).setEnabled(false);
                    buttons.get(i).setVisibility(View.INVISIBLE);
                }
                break;
        }
        setTitle(title);

        new AttemptPatientName().execute();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    protected void onResume() {
        SharedPreferences sharedPref = Camas.this.getSharedPreferences(
                getString(R.string.preferencs_file), Context.MODE_PRIVATE);
        int chequeado = sharedPref.getInt("chequeado",0);

        Button b_Cama1,b_Cama2,b_Cama3,b_Cama4,b_Cama5,b_Cama6,b_Cama7,b_Cama8,b_Cama9,b_Cama10,b_Cama11,b_Cama12,b_Cama13,b_Cama14;

        Bundle b=Camas.this.getIntent().getExtras();
        if(b!=null)
        {
            sector=b.getInt("noSector");
        }

        Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
        Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);


        for (int i=0; i<14 && sector==0; i++)
        {
            alertaA = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"A",0);
            if (alertaA==1)
            {
                buttons.get(i).setBackground(rojo);
                buttons.get(i).setTextColor(Color.parseColor("#000000"));
            }
            else
            {
                buttons.get(i).setBackground(verde);
                buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
            }
        }

        for (int i=0; i<14 && sector==1; i++)
        {
            alertaB = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"B",0);
            if (alertaB==1)
            {
                buttons.get(i).setBackground(rojo);
                buttons.get(i).setTextColor(Color.parseColor("#000000"));
            }
            else
            {
                buttons.get(i).setBackground(verde);
                buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
            }
        }
        for (int i=0; i<14 && sector==2; i++)
        {
            alertaC = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"C",0);
            if (alertaC==1)
            {
                buttons.get(i).setBackground(rojo);
                buttons.get(i).setTextColor(Color.parseColor("#000000"));
            }
            else
            {
                buttons.get(i).setBackground(verde);
                buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
            }
        }
        for (int i=0; i<14 && sector==3; i++)
        {
            alertaD = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"D",0);
            if (alertaD==1)
            {
                buttons.get(i).setBackground(rojo);
                buttons.get(i).setTextColor(Color.parseColor("#000000"));
            }
            else
            {
                buttons.get(i).setBackground(verde);
                buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
            }
        }
        Camas.this.mHandler.postDelayed(m_Runnable, 500);
        super.onResume();
    }

    @Override
    protected void onStop() {
        this.mHandler.removeCallbacks(this.m_Runnable);
        super.onStop();

    }

    private final Runnable m_Runnable = new Runnable()
    {
        public void run()

        {

            SharedPreferences sharedPref = Camas.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            int chequeado = sharedPref.getInt("chequeado",0);

            if(chequeado==1)
            {
                Bundle b=Camas.this.getIntent().getExtras();
                if(b!=null)
                {
                    sector=b.getInt("noSector");
                }

                Drawable rojo = getResources().getDrawable(R.drawable.boton_rojo);
                Drawable verde = getResources().getDrawable(R.drawable.boton_oficial);


                for (int i=0; i<14 && sector==0; i++)
                {
                    alertaA = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"A",0);
                    if (alertaA==1)
                    {
                        buttons.get(i).setBackground(rojo);
                        buttons.get(i).setTextColor(Color.parseColor("#000000"));
                    }
                    else
                    {
                        buttons.get(i).setBackground(verde);
                        buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
                    }
                }

                for (int i=0; i<14 && sector==1; i++)
                {
                    alertaB = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"B",0);
                    if (alertaB==1)
                    {
                        buttons.get(i).setBackground(rojo);
                        buttons.get(i).setTextColor(Color.parseColor("#000000"));
                    }
                    else
                    {
                        buttons.get(i).setBackground(verde);
                        buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
                    }
                }
                for (int i=0; i<14 && sector==2; i++)
                {
                    alertaC = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"C",0);
                    if (alertaC==1)
                    {
                        buttons.get(i).setBackground(rojo);
                        buttons.get(i).setTextColor(Color.parseColor("#000000"));
                    }
                    else
                    {
                        buttons.get(i).setBackground(verde);
                        buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
                    }
                }
                for (int i=0; i<14 && sector==3; i++)
                {
                    alertaD = sharedPref.getInt(getString(R.string.data_alarm_cama)+"_"+camas.get(i)+"_"+"D",0);
                    if (alertaD==1)
                    {
                        buttons.get(i).setBackground(rojo);
                        buttons.get(i).setTextColor(Color.parseColor("#000000"));
                    }
                    else
                    {
                        buttons.get(i).setBackground(verde);
                        buttons.get(i).setTextColor(Color.parseColor("#4FC5D3"));
                    }
                }

            }
            Camas.this.mHandler.postDelayed(m_Runnable, 500);
        }

    };


    public void cancelAlarm() {
        Intent intent = new Intent(getApplicationContext(), StatusAlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, StatusAlarmReceiver.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    private class AttemptPatientName extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args)
        {
            int success;
            if(isCancelled)
            {
                return "correcto";
            }
            buttonCounter=0;
            for (buttonCounter=0; buttonCounter<buttons.size(); buttonCounter++) {
                try {

                    List parametros = new ArrayList();
                    parametros.add(new BasicNameValuePair("cama", Integer.toString(buttonCounter+1)));
                    parametros.add(new BasicNameValuePair("sector", title.substring(title.lastIndexOf("r")+1).trim()));

                    // getting product details by making HTTP request
                    JSONObject json = jsonParser.makeHttpRequest(serverUrl, "POST", parametros);


                    // json success tag
                    success = json.getInt(TAG_SUCCESS);
                    if (success == 1 )
                    {
                        if(json.has("apellido") && json.has("nombre"))
                        {
                            nombre_paciente=json.getString("apellido")+" "+json.getString("nombre");
                        }
                        else
                        {
                            nombre_paciente="Sin Datos";
                        }
                        camas_text.add(buttons.get(buttonCounter).getText()+"\n"+nombre_paciente);
                        error=0;

                    }
                    else
                    {
                        nombre_paciente="Sin Datos";
                        camas_text.add(buttons.get(buttonCounter).getText()+"\n"+nombre_paciente);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return "Error de conexión con el servidor!";
                }
            }
            Camas.this.runOnUiThread(new Runnable() {
                public void run()
                {
                    int j=0;
                    for (Button cama:buttons) {
                        cama.setText(camas_text.get(j));
                        j++;
                    }

                }
            });
            return "correcto";
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override

        protected void onPostExecute(String file_url)
        {
            // dismiss the dialog once product deleted
            if (file_url != null && !file_url.isEmpty() && !file_url.contains("correcto") && error==0) {
                error=1;
                Toast.makeText(Camas.this, file_url, Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        }


    }

    private View.OnClickListener camaButtonListener= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent n_activity=new Intent(view.getContext(),Parametros.class);
            n_activity.putExtra("noCama",view.getId());
            n_activity.putExtra("noSector",sector);
            startActivity(n_activity);
        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Intent n_act=new Intent(this,Sectores.class);
            n_act.putExtra("noSector",sector);
            startActivity(n_act);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_camas, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.logout) {
            SharedPreferences sharedPref = Camas.this.getSharedPreferences(
                    getString(R.string.preferencs_file), Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPref.edit();
            edit.clear();
            edit.apply();

            Intent serviceI = new Intent(Camas.this, CheckStatusService.class);
            stopService(serviceI);

            NotificationCompat.Builder mBuilder;
            NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

            int icono = R.drawable.icon_b;
            Intent i=new Intent(Camas.this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(Camas.this, 0, i, 0);

            mBuilder =new NotificationCompat.Builder(getApplicationContext(),"01")
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(icono)
                    .setContentTitle(getText(R.string.title_notificacion_logout))
                    .setContentText(getText(R.string.message_notificacion_logout))
                    .setAutoCancel(true)
                    .setColor(0xFF00FF00)
                    .setOnlyAlertOnce(true);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mBuilder.setChannelId("com.ARI");
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        "com.ARI",
                        "ARI",
                        NotificationManager.IMPORTANCE_DEFAULT
                );
                if (mNotifyMgr != null) {
                    mNotifyMgr.createNotificationChannel(channel);
                }
            }
            mNotifyMgr.notify(1, mBuilder.build());

            cancelAlarm();

            Intent n_activity=new Intent(Camas.this,MainActivity.class);
            startActivity(n_activity);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        int sector=0;
        Intent n_activity=new Intent(this,Camas.class);
        if (id == R.id.nav_send) {

        }
        else{
            switch (id) {
                case R.id.nav_sector_b:
                    sector = 1;
                    break;
                case R.id.nav_sector_c:
                    sector = 2;
                    break;
                case R.id.nav_sector_d:
                    sector = 3;
                    break;
            }
            n_activity.putExtra("noSector",sector);
            startActivity(n_activity);
        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
